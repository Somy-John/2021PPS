k = list(map(int,input().split()))[1]
print(sorted(list(map(int,input().split())))[k-1])